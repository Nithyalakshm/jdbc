import java.sql.SQLException;

import business.DepartmentBusiness;

public class DepartmentMain {

    public static void main(String[] args) throws Exception {

        DepartmentBusiness departmentBusiness = new DepartmentBusiness();
        departmentBusiness.find(20);

    }
}
