import business.DepartmentBusiness;
import business.EmployeeBusiness;

public class EmployeeMain {

    public static void main(String[] args) throws Exception {

        EmployeeBusiness employeeBusiness = new EmployeeBusiness();
        employeeBusiness.find(7782);

    }
}
