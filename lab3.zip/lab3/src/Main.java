import java.sql.*;
import java.util.Properties;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    public static void main(String[] args) throws SQLException {
        /* Load JDBC Driver. */
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        String url = "jdbc:postgresql://localhost/postgres";

        Properties props = new Properties();
        props.setProperty("user", "postgres");
        props.setProperty("password", "nithya");

        Connection connection = null;

        try {
            connection = DriverManager.getConnection(url, props);
            /* Requests to DB will be here */

            System.out.println("DB Connected");
            //exercise 1
            displayDepartment(connection);
            //exercise 2
             moveDepartment(connection, 7369, 20);
            //exercise 3
            displayTable(connection, "emp");
            //exercise 4
           displayEmp(connection);
            //exercise 3 using prepared statement
            displayTableWithPrepStmt(connection);

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null)
                try {
                    connection.close();
                } catch (SQLException ignore) {
                    ignore.printStackTrace();
                }
        }
    }

    public static void displayDepartment(Connection connexion) throws SQLException {
        Statement statement = connexion.createStatement();
        ResultSet resultat = statement.
                executeQuery("SELECT deptno, dname, loc FROM dept");

        while (resultat.next()) {
            int deptno = resultat.getInt("deptno");
            String dname = resultat.getString("dname");
            String loc = resultat.getString("loc");

            System.out.println("Department " + deptno + " is for "
                    + dname + " and located in " + loc);
        }
        resultat.close();
        statement.close();
    }

    private static boolean departmentExists(Connection connection, int deptno) throws SQLException {
        String sql = "SELECT 1 FROM dept WHERE deptno = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1, deptno);
        ResultSet result = statement.executeQuery();
        boolean exists = result.next();
        result.close();
        statement.close();
        return exists;
    }

    public static void moveDepartment(Connection connection, int empno, int newDeptno) throws SQLException {
        boolean depExists = departmentExists(connection, newDeptno);
        if (!depExists) {
            throw new IllegalArgumentException("Target department " + newDeptno + " does not exist.");
        }
        String sql = "UPDATE emp SET deptno = ? WHERE empno = ? ";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1, newDeptno);
        statement.setInt(2, empno);
        int updatedRows = statement.executeUpdate();
        if (updatedRows == 1) {
            System.out.println("business.EmployeeBusiness " + empno + " successfully moved to department " + newDeptno);
        } else {
            System.out.println("No employee found with ID: " + empno);
        }
        statement.close();
    }

    // Implementation for Exercise 3 - displayTable using  Statement

    public static void displayTable(Connection connection, String tableName) throws SQLException {

        Statement statement = null;
        ResultSet result = null;

        try {

            statement = connection.createStatement();
            boolean valid = validateinput(tableName);
            if (!valid) {
                throw new SQLException("Invalid table name. Please enter a valid table name.");
            }
            result = statement.executeQuery("SELECT * FROM " + tableName);

            ResultSetMetaData metaData = result.getMetaData();
            int columnCount = metaData.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                System.out.print(metaData.getColumnName(i) + "|");
            }
            System.out.println();
            while (result.next()) {
                for (int j = 1; j <= columnCount; j++) {
                    System.out.print(result.getString(j) + "| ");
                }
                System.out.println();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (result != null)
                result.close();
            if (statement != null)
                statement.close();
        }

    }

    // Implementation for Exercise 4 - using prepared statement

    public static void displayEmp(Connection connection) throws SQLException {

        PreparedStatement preparedStatement = null;
        ResultSet results = null;

        try {

            preparedStatement = connection.prepareStatement("SELECT * FROM emp WHERE efirst = ? AND ename = ?");

            // Input the first name and last name
            Scanner sc = new Scanner(System.in);
            String firstName = sc.next();
            preparedStatement.setString(1, firstName);
            String lastName = sc.next();
            preparedStatement.setString(2, lastName);

            results = preparedStatement.executeQuery();

            ResultSetMetaData metaData = results.getMetaData();
            int columnCount = metaData.getColumnCount();

            for (int i = 1; i <= columnCount; i++) {
                System.out.print(metaData.getColumnName(i) + "|");
            }
            while (results.next()) {
                for (int j = 1; j <= columnCount; j++) {
                    System.out.print(results.getString(j) + "| ");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (results != null)
                results.close();
            if (preparedStatement != null)
                preparedStatement.close();

        }
    }


    public static boolean validateinput(String input) throws SQLException {

        try {
            String validname = "^[a-zA-Z][a-zA-Z0-9_]*$";
            Pattern pattern = Pattern.compile(validname);

            Matcher matcher = pattern.matcher(input);

            // Return true if the table name matches the pattern, false otherwise
            boolean valid =  matcher.matches();
            System.out.print(input);
            System.out.print(valid);
            return valid;

        } catch (NumberFormatException e) {
            throw new SQLException("Invalid input. Please enter a valid number.");
        }

    }

    // Implementation for Exercise 3 - displayTable using  Prepared Statement

    public static void displayTableWithPrepStmt(Connection connection) throws SQLException {

        PreparedStatement preparedStatement = null;
        ResultSet result = null;

        try {

            // Input the table name

            Scanner sc = new Scanner(System.in);
            String tableName = sc.next();

            boolean valid = validateinput(tableName);
            if (!valid) {
                throw new SQLException("Invalid table name. Please enter a valid table name.");
            }

            //result = statement.executeQuery("SELECT * FROM " + tableName);
            preparedStatement = connection.prepareStatement("SELECT * FROM ? ");
            preparedStatement.setString(1, tableName);

            result = preparedStatement.executeQuery();

            // Throws an error
            // org.postgresql.util.PSQLException: ERROR: syntax error at or near "$1"
            //  Position: 15

            ResultSetMetaData metaData = result.getMetaData();
            int columnCount = metaData.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                System.out.print(metaData.getColumnName(i) + "|");
            }
            System.out.println();
            while (result.next()) {
                for (int j = 1; j <= columnCount; j++) {
                    System.out.print(result.getString(j) + "| ");
                }
                System.out.println();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (result != null)
                result.close();
            if (preparedStatement != null)
                preparedStatement.close();
        }

    }

}