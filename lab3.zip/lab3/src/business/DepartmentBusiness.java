package business;

import dao.DAO;
import dao.DeptDAO;
import model.Department;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class DepartmentBusiness {

    protected Connection connect = null;

    public DepartmentBusiness() {

        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        String url = "jdbc:postgresql://localhost/postgres";

        Properties props = new Properties();
        props.setProperty("user", "postgres");
        props.setProperty("password", "nithya");

        try {
            connect = DriverManager.getConnection(url, props);
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("DB Connected");
    }

    public Department find(int id) {

        Department department = new Department();
        DAO<Department> departmentDao = new DeptDAO(connect);
        Department dept = departmentDao.find(id);
        System.out.println("dept no" + dept.getDeptNo());
        System.out.println("dept name" + dept.getDname());
        System.out.println("loc" + dept.getLoc());

        return department;
    }

    public boolean create(Department object) {
        return false;
    }

    public boolean update(Department object) {
        return false;
    }

    public boolean delete(Department object) {
        return false;
    }
}
