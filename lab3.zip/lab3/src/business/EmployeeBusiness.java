package business;

import dao.DAO;
import dao.DeptDAO;
import dao.EmployeeDAO;
import model.Department;
import model.Employee;

import java.sql.*;
import java.util.Properties;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmployeeBusiness {

    protected Connection connection = null;

    public EmployeeBusiness() {

        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        String url = "jdbc:postgresql://localhost/postgres";

        Properties props = new Properties();
        props.setProperty("user", "postgres");
        props.setProperty("password", "nithya");

        try {
            connection = DriverManager.getConnection(url, props);
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("DB Connected");

    }

    public Employee find(int idManager){
        Employee employee = new Employee();
        DAO<Employee> employeeDao = new EmployeeDAO(connection);
        Employee emp = employeeDao.find(idManager);
        System.out.println("emp no" + emp.getEmpNo());
        System.out.println("emp name" + emp.getEname());
        System.out.println("emp first" + emp.getEfirst());
        System.out.println("job" + emp.getJob());
        System.out.println("mgr emp no" + emp.getMgr().getEmpNo());
        System.out.println("hiredate" + emp.getHireDate());
        System.out.println("sal" + emp.getSal());
        System.out.println("comm" + emp.getComm());
        System.out.println("deptno" + emp.getDepartment().getDeptNo());
        System.out.println("tel" + emp.getTel());

        return employee;

    }

}