package dao;

import java.sql.Connection;

public class DAOFactory {

    protected static Connection connect = null;

    public static DeptDAO getDeptDAO() {
        return new DeptDAO(connect);
    }

    public static EmployeeDAO getEmployeeDAO() {
        return new EmployeeDAO(connect);
    }

}
