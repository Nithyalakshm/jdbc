package dao;

import model.Department;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DeptDAO extends DAO<Department> {

    public DeptDAO(Connection connect) {
        super(connect);
    }

    public Department find(int id) {
        Department department = new Department();

        PreparedStatement preparedStatement = null;
        ResultSet results = null;

        try {
            preparedStatement = connect.prepareStatement("SELECT * FROM dept WHERE deptno = ?");
            preparedStatement.setInt(1, id);
            results = preparedStatement.executeQuery();

            if (results.next()) {
                department.setDeptNo(results.getInt("deptno"));
                department.setDname(results.getString("dname"));
                department.setLoc(results.getString("loc"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            return department;
       }
    }

    public boolean create(Department object) {
        return false;
    }

    public boolean update(Department object) {
        return false;
    }

    public boolean delete(Department object) {
        return false;
    }

}
