package dao;

import model.Department;
import model.Employee;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

public class EmployeeDAO extends DAO<Employee> {


    public EmployeeDAO(Connection connect) {
       super(connect);
    }

    public Employee find(int id) {

        Employee employee = new Employee();
        PreparedStatement preparedStatement = null;
        ResultSet results = null;

        try {
            preparedStatement = connect.prepareStatement("SELECT * FROM emp WHERE empno = ?");
            preparedStatement.setInt(1, id);
            results = preparedStatement.executeQuery();
            if (results.next()) {

                employee.setEmpNo(Long.valueOf(results.getInt("empno")));
                employee.setEname(results.getString("ename"));
                employee.setEfirst(results.getString("efirst"));
                employee.setJob(results.getString("job"));

                int managerId = results.getInt("mgr");
                if (managerId > 0 && managerId != id) {
                    Employee manager = find(managerId); // Recursive call
                    employee.setMgr(manager);
                }

                employee.setHireDate(results.getDate("hiredate"));
                employee.setSal((int) results.getDouble("sal"));
                employee.setComm((int)results.getDouble("comm"));
                Department dept = new Department();
                dept.setDeptNo(results.getInt("deptno"));
                employee.setDepartment(dept);
                employee.setTel(results.getInt("tel"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return employee;
    }


    public boolean create(Employee object) {
        return false;
    }

    public boolean update(Employee object) {
        return false;
    }

    public boolean delete(Employee object) {
        return false;
    }

}
