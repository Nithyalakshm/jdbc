package servlet;

public class DepartmentServlet {
}
